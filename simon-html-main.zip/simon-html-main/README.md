# simon-html

This deliverable demonstrates the use of basic HTML elements for structure, basic formatting, input, output, links, and drawing.
